//Joshua Ng
public interface PersonType{
  public String jobTitle();
};